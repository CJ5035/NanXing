﻿using EntityFramework.Extensions;
using FineUIPro;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Entity;
using System.Configuration;
using SQLHelper;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;

namespace AppBoxPro.Produce
{
    public partial class ProduceSummaryChart : PageBase
    {
        #region ViewPower

        /// <summary>
        /// 本页面的浏览权限，空字符串表示本页面不受权限控制
        /// </summary>
        public override string ViewPower
        {
            get
            {
                return "ProduceEdit";
            }
        }

        #endregion
        protected void Page_Init(object sender, EventArgs e)
        {
            InitGrid();
        }

        private void InitGrid()
        {
            DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();

            int month = 12;
            int date = month;

            object[] obj = new object[] { date };
            DataTable dt =  DbHelperSQL.ExecuteProc_ReturnDataTable("GetHBTB", obj, 300);

            dt=NewDtByTJ(dt);
            FineUIPro.BoundField bf;

            foreach(DataColumn dc in dt.Columns)
            {
                bf = new FineUIPro.BoundField();
                bf.DataField = dc.ColumnName;
                bf.DataFormatString = "{0}";
                bf.ColumnID= dc.ColumnName;
                bf.HeaderText = dc.ColumnName;
                bf.Width = 120;
                //Debug.WriteLine(dc.ColumnName);

                if (dc.ColumnName == "机台号")
                {
                    bf.EnableLock = true;
                    bf.Locked = true;
                }
                Grid2.Columns.Add(bf);
            }
            Grid2.DataKeyNames = new string[] { "机台号" };

            dt = null;
            dt = DbHelperSQL.ExecuteProc_ReturnDataTable("GetRYHBTB", obj, 300);
            dt = NewYGDtByTJ(dt);
            bf=null;

            foreach (DataColumn dc in dt.Columns)
            {
                bf = new FineUIPro.BoundField();
                bf.DataField = dc.ColumnName;
                bf.DataFormatString = "{0}";
                bf.ColumnID = dc.ColumnName;

                bf.HeaderText = dc.ColumnName;
                bf.Width = 120;
                //Debug.WriteLine(dc.ColumnName);
                if (dc.ColumnName == "生产人员")
                {
                    bf.EnableLock = true;
                    bf.Locked = true;
                }
                Grid4.Columns.Add(bf);
            }
            Grid4.DataKeyNames = new string[] { "生产人员" };
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadData();
            }
        }

        private void LoadData()
        {

            // 每页记录数
            //Grid1.PageSize = ConfigHelper.PageSize;
            //BindDDLChineseName();
          

            BindDatePicker();
            BindGrid();
            BindGrid2();

            BindGrid3();
            BindGrid4();

        }
        

        private void BindDatePicker()
        {
            //上月1号
            dpStart.SelectedDate=DateTime.Now.AddDays(1 - DateTime.Now.Day).AddMonths(-1);
            //上月最后一天
            dpEnd.SelectedDate=DateTime.Now.AddDays(-DateTime.Now.Day);

            //Panel8.IFrameUrl = "~/Finance/ReimburseChart3.aspx?Date1=" + dpStart.SelectedDate.Value.ToString("yyyy-MM-dd") + "&&Date2=" + dpEnd.SelectedDate.Value.ToString("yyyy-MM-dd")+"&&class=class1&&class1_param=";
            
        }

        private void BindDDLChineseName()
        {
            //var q = DB.Users.Select(u => u.ChineseName).Distinct();
            //    ddlChineseName.DataSource = q;
            //    ddlChineseName.DataBind();
            //    return;
        }

        



        private void ResolveEnableStatusButtonForGrid(MenuButton btn, Grid grid, bool enabled)
        {
            string enabledStr = "启用";
            if (!enabled)
            {
                enabledStr = "禁用";
            }
            btn.OnClientClick = grid.GetNoSelectionAlertInParentReference("请至少应该选择一项记录！");
            btn.ConfirmText = string.Format("确定要{1}选中的<span class=\"highlight\"><script>{0}</script></span>项记录吗？", grid.GetSelectedCountReference(), enabledStr);
            btn.ConfirmTarget = FineUIPro.Target.Top;
        }


        


       
        protected void Grid3_Sort(object sender, FineUIPro.GridSortEventArgs e)
        {
            Grid3.SortDirection = e.SortDirection;
            Grid3.SortField = e.SortField;
            BindGrid3();
        }


        protected void Grid3_PageIndexChange(object sender, FineUIPro.GridPageEventArgs e)
        {
            Grid3.PageIndex = e.NewPageIndex;
            BindGrid3();
        }

        protected void Window1_Close(object sender, EventArgs e)
        {
            BindGrid();
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindGrid();
            BindGrid2();
            BindGrid3();
            BindGrid4();

            //ChangePanel6IFrameUrl();

        }

        private void SetSelectedUsersEnableStatus(bool enabled)
        {
            List<int> ids = GetSelectedDataKeyIDs(Grid1);

            DB.reimbursements.Where(u => ids.Contains(u.ID)).Update(u => new Reimbursement { passed = enabled });

            BindGrid();
        }
        
        protected void Grid1_RowClick(object sender, GridRowClickEventArgs e)
        {
            
        }
        protected void Grid4_RowClick(object sender, GridRowClickEventArgs e)
        {

        }

        private void ChangePanel3IFrameUrl()
        {
            int ID = GetSelectedDataKeyID(Grid1);
            string ChinseseName= GetSelectedDataKey(Grid1, 1);
            string Date1 = "";
            string Date2 = "";
            if (dpStart.SelectedDate.HasValue && dpEnd.SelectedDate.HasValue)
            {
                Date1 = dpStart.SelectedDate.Value.ToString("yyyy-MM-dd");
                Date2 = dpEnd.SelectedDate.Value.ToString("yyyy-MM-dd");
            }
            //Panel3.IFrameUrl = "~/Finance/ReimburseChart1.aspx?ID=" + ID + "&&" + "Date1=" + Date1 + "&&Date2=" + Date2+"&&ChineseName="+ HttpUtility.UrlEncode(ChinseseName, System.Text.Encoding.UTF8);
        }

        protected void Grid2_RowClick(object sender, GridRowClickEventArgs e)
        {
            //ChangePanel6IFrameUrl();
        }
        protected void rblTime_SelectedIndexChanged(object sender, EventArgs e)
        {
            //BindPanel2();
            BindGrid();
            BindGrid2();
            BindGrid4();

        }
        private void BindGrid()
        {
            string name = GetIdentityName();

            DateTime dtStart;
            DateTime dtEnd;

            dtStart = dpStart.SelectedDate.Value;
            dtEnd = dpEnd.SelectedDate.Value;

           
            string sql = @" select case when t3.position is null then '无登记机台' when t3.position='' then '无登记机台'  else t3.position end position,
                sum(t3.卷数)总卷数,sum(t3.面积)总面积 from (                
                select TelenOrderDtlEntry.worker,TelenOrderDtlEntry.position,
                case when TelenOrderDtlEntry.ScCount is null then t1.卷数 else TelenOrderDtlEntry.ScCount end 卷数,
                case when TelenOrderDtlEntry.ScCount is null then t1.面积 else 
				(case when  (t1.长度+(t1.边距*2))*(t1.宽度+t1.间距)*t1.张数*TelenOrderDtlEntry.ScCount/1000000 is null then 0 else CAST((t1.长度+(t1.边距*2))*(t1.宽度+t1.间距)*t1.张数*TelenOrderDtlEntry.ScCount/1000000 as decimal(38, 2)) end) end 面积
                from                 
                  (select deliverno 订单号,
                  case when cpwidth is null then 0 else cpwidth end 长度,
                case when cpheight is null then 0 else cpheight end 宽度,
                case when djpages is null then 0 else djpages end 张数,
                case when bianju is null then 0  else  CAST(bianju as decimal(38, 2)) end 边距, 
                case when jianju is null then 0  else jianju end 间距,
				case when unit ='卷' then 
				(case when quantity  is null then 0 else quantity end ) else 
				(case when quantity  is null then 0 else CAST(quantity/ 
				(case when (case when djpages is null then 0 else djpages end)=0 then  1 else djpages end)as decimal(38, 2)) end ) end 卷数,
               case when unit ='卷' then 
                (case when  (cpwidth+(bianju*2))*(cpheight+jianju)*djpages*quantity/1000000 is null then 0 else CAST((cpwidth+(bianju*2))*(cpheight+jianju)*djpages*quantity/1000000 as decimal(38, 2)) end)
                else (case when  (cpwidth+(bianju*2))*(cpheight+jianju)*quantity/1000000 is null then 0 else CAST((cpwidth+(bianju*2))*(cpheight+jianju)*quantity/1000000 as decimal(38, 2)) end) end  面积,
				 prodate 生产日期
                from [telendbs].dbo.TelenOrderDtl  where prodate between '" + dtStart.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dtEnd.ToString("yyyy-MM-dd 23:59:59") + @"'  )t1 left join  TelenOrderDtlEntry  on TelenOrderDtlEntry.deliverno=t1.订单号) t3 
                group by t3.position";
            DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();
            DataTable dt = DbHelperSQL.ReturnDataTable(sql);


            Decimal price1 = 0;
            Decimal price2 = 0;

            foreach (DataRow item in dt.Rows)
            {
                price1 += Convert.ToDecimal(item["总卷数"]);
                price2 += Convert.ToDecimal(item["总面积"]);
            }

            JObject summary = new JObject();
            summary.Add("position", "合计");
            summary.Add("总卷数", price1.ToString("F2"));
            summary.Add("总面积", price2.ToString("F2"));
            

            Grid1.RecordCount = dt.Rows.Count;
            //q = SortAndPage(q, Grid1);
            dt = GetPagedDataTable(dt, Grid1);
            Grid1.DataSource = dt;
            Grid1.DataBind();
            Grid1.SummaryData = summary;

            Grid1.SelectedRowIndex = 0;
            //ChangePanel3IFrameUrl();
        }
        protected void Grid1_Sort(object sender, FineUIPro.GridSortEventArgs e)
        {
            Grid1.SortDirection = e.SortDirection;
            Grid1.SortField = e.SortField;
            BindGrid();
        }


        protected void Grid1_PageIndexChange(object sender, FineUIPro.GridPageEventArgs e)
        {
            Grid1.PageIndex = e.NewPageIndex;
            BindGrid();
        }

        private void BindGrid4()
        {
            string name = GetIdentityName();

            int month = int.Parse(rblTime.SelectedValue);

            int date = month;

            object[] obj = new object[] { date };
            DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();

            DataTable dt = DbHelperSQL.ExecuteProc_ReturnDataTable("GetRYHBTB", obj, 300);
            dt = NewYGDtByTJ(dt);

            Dictionary<string, decimal> dic = new Dictionary<string, decimal>();

            foreach (DataRow dr in dt.Rows)
            {
                foreach (DataColumn dc in dt.Columns)
                {
                    if (dc.ColumnName.Contains("产量"))
                    {
                        decimal value = 0;
                        if (!dic.TryGetValue(dc.ColumnName, out value))
                        {
                            dic.Add(dc.ColumnName, 0);
                        }
                        dic[dc.ColumnName] = value + Convert.ToDecimal(dr[dc.ColumnName]);
                    }
                }
            }

            JObject summary = new JObject();
            summary.Add("生产人员", "合计");
            foreach (KeyValuePair<string, decimal> item in dic)//System.InvalidOperationException: 'Collection was modified; enumeration operation may not execute.'
            {
                
                summary.Add(item.Key, dic[item.Key]);
            }
            Grid4.SummaryData = summary;

            Grid4.RecordCount = dt.Rows.Count;
            //q = SortAndPage(q, Grid1);
            dt = GetPagedDataTable(dt, Grid4);
            Grid4.DataSource = dt;
            Grid4.DataBind();


            Grid4.SelectedRowIndex = 0;
            //ChangePanel3IFrameUrl();
        }
        protected void Grid4_Sort(object sender, FineUIPro.GridSortEventArgs e)
        {
            Grid4.SortDirection = e.SortDirection;
            Grid4.SortField = e.SortField;
            BindGrid4();
        }


        protected void Grid4_PageIndexChange(object sender, FineUIPro.GridPageEventArgs e)
        {
            Grid4.PageIndex = e.NewPageIndex;
            BindGrid4();
        }

        /// <summary>
        /// datatable 分页
        /// </summary>
        /// <param name="pageIndex">页面序号</param>
        /// <param name="pageSize">每页数量</param>
        /// <param name="source">原datatable</param>
        /// <returns>分页后的数据datatable</returns>
        private DataTable GetPagedDataTable( DataTable source, Grid grid)
        {
           
            int rowbegin = grid.PageIndex * grid.PageSize;
            int rowend = (grid.PageIndex + 1) * grid.PageSize;

            string sortField = grid.SortField;
            string sortDirection = grid.SortDirection;
            //Debug.WriteLine(sortField + "." + sortDirection);

            DataView view2 = source.DefaultView;

            view2.Sort = String.Format("{0} {1}", sortField, sortDirection);
            DataTable table = view2.ToTable();

            DataTable paged = table.Clone();
            //foreach (DataRow dr in paged.Rows)
            //    Debug.WriteLine(dr["生产日期"]);
            if (rowend > source.Rows.Count)
            {
                rowend = source.Rows.Count;
            }

            for (int i = rowbegin; i < rowend; i++)
            {
                paged.ImportRow(table.Rows[i]);
            }

            return paged;
        }
        private void BindGrid2()
        {
            string name = GetIdentityName();
            int month = int.Parse(rblTime.SelectedValue);
           
            
            int date = month;

            object[] obj = new object[] { date };
            DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();

            DataTable dt = DbHelperSQL.ExecuteProc_ReturnDataTable("GetHBTB", obj, 300);
            dt=NewDtByTJ(dt);

           
            Dictionary<string, decimal> dic = new Dictionary<string, decimal>();
            
            foreach(DataRow dr in dt.Rows)
            {
                foreach (DataColumn dc in dt.Columns)
                {
                    if (dc.ColumnName.Contains("产量"))
                    {
                        decimal value = 0;
                        if (!dic.TryGetValue(dc.ColumnName, out value))
                        {
                            dic.Add(dc.ColumnName, 0);
                        }
                        dic[dc.ColumnName] = value + Convert.ToDecimal(dr[dc.ColumnName]);
                    }
                }
            }

            JObject summary = new JObject();
            summary.Add("机台号", "合计");
            foreach (KeyValuePair<string, decimal> item in dic)//System.InvalidOperationException: 'Collection was modified; enumeration operation may not execute.'
            {
                
                summary.Add(item.Key, dic[item.Key]);
            }
            Grid2.SummaryData = summary;

            Grid2.RecordCount = dt.Rows.Count;
            //q = SortAndPage(q, Grid1);
            dt = GetPagedDataTable(dt, Grid2);
            Grid2.DataSource = dt;
            Grid2.DataBind();
            Grid2.SelectedRowIndex = 0;
            //ChangePanel3IFrameUrl();
        }
        string[] positionArr = { "1号机", "2号机", "3号机", "4号机", "6号机", "7号机" };
        public DataTable NewDtByTJ(DataTable oldDt)
        {
            DataTable newDt = new DataTable();
            newDt.Columns.Add("机台号");
            for (int i = 0; i < oldDt.Rows.Count; i++)
            {
                string month = oldDt.Rows[i][0].ToString().Substring(0, 7);
                newDt.Columns.Add(month + "产量");
                newDt.Columns.Add(month + "环比");
                newDt.Columns.Add(month + "同比");
               
            }
            for (int j = 1; j < oldDt.Columns.Count - 1; j++)
            {
                if ((j - 1) % 3 == 0)
                {
                    Debug.WriteLine("第" + j + "列,新建第 " + (newDt.Rows.Count + 1) + "行");
                    DataRow dr = newDt.NewRow();
                    dr[0] = positionArr[(j - 1) / 3];
                    newDt.Rows.Add(dr);
                }
            }
            for (int i = 0; i < oldDt.Rows.Count; i++)
            {
                int[] yArr = new int[3] { 3 * i + 1, 3 * i + 2, 3 * i + 3 };

                for (int j = 1; j < oldDt.Columns.Count ; j++)
                {
                    newDt.Rows[(j - 1) / 3][yArr[(j - 1) % 3]] = oldDt.Rows[i][j];
                }
            }
            Debug.WriteLine("newDt:行数"+newDt.Rows.Count);
            Debug.WriteLine("newDt:列数" + newDt.Columns.Count);

            Debug.WriteLine("oldDt:行数" + oldDt.Rows.Count);
            Debug.WriteLine("oldDt:列数" + oldDt.Columns.Count);
            //for (int i = 0; i < newDt.Rows.Count; i++)
            //{
            //    for (int j = 0; j < newDt.Columns.Count; j++)
            //    {
            //        Debug.WriteLine(newDt.Rows[i][j].ToString()+" ");
            //    }
            //    //Debug.WriteLine("");
            //}
            return newDt;
        }

        string[] staffArr = { "秦海霞", "华贵梅", "杨曼曼", "梁小清"};
        public DataTable NewYGDtByTJ(DataTable oldDt)
        {
            DataTable newDt = new DataTable();
            newDt.Columns.Add("生产人员");
            for (int i = 0; i < oldDt.Rows.Count; i++)
            {
                string month = oldDt.Rows[i][0].ToString().Substring(0, 7);
                newDt.Columns.Add(month + "产量");
                newDt.Columns.Add(month + "环比");
                newDt.Columns.Add(month + "同比");

            }
            for (int j = 1; j < oldDt.Columns.Count - 1; j++)
            {
                if ((j - 1) % 3 == 0)
                {
                    Debug.WriteLine("第" + j + "列,新建第 " + (newDt.Rows.Count + 1) + "行");
                    DataRow dr = newDt.NewRow();
                    dr[0] = staffArr[(j - 1) / 3];
                    newDt.Rows.Add(dr);
                }
            }
            for (int i = 0; i < oldDt.Rows.Count; i++)
            {
                int[] yArr = new int[3] { 3 * i + 1, 3 * i + 2, 3 * i + 3 };

                for (int j = 1; j < oldDt.Columns.Count; j++)
                {
                    newDt.Rows[(j - 1) / 3][yArr[(j - 1) % 3]] = oldDt.Rows[i][j];
                }
            }
            Debug.WriteLine("newDt:行数" + newDt.Rows.Count);
            Debug.WriteLine("newDt:列数" + newDt.Columns.Count);

            Debug.WriteLine("oldDt:行数" + oldDt.Rows.Count);
            Debug.WriteLine("oldDt:列数" + oldDt.Columns.Count);
            for (int i = 0; i < newDt.Rows.Count; i++)
            {
                for (int j = 0; j < newDt.Columns.Count; j++)
                {
                    Debug.WriteLine(newDt.Rows[i][j].ToString() + " ");
                }
                //Debug.WriteLine("");
            }
            return newDt;
        }


        protected void Grid2_Sort(object sender, FineUIPro.GridSortEventArgs e)
        {
            Grid2.SortDirection = e.SortDirection;
            Grid2.SortField = e.SortField;
            BindGrid2();
        }


        protected void Grid2_PageIndexChange(object sender, FineUIPro.GridPageEventArgs e)
        {
            Grid2.PageIndex = e.NewPageIndex;
            BindGrid2();
        }

        private void BindGrid3()
        {

            string name = GetIdentityName();

            DateTime dtStart;
            DateTime dtEnd;

            dtStart = dpStart.SelectedDate.Value;
            dtEnd = dpEnd.SelectedDate.Value;

            string sql = @"select case when t3.worker is null then '无登记人员' when t3.worker='' then '无登记人员'  else t3.worker end worker, sum(t3.卷数)总卷数,sum(t3.面积)总面积 from (                
                select TelenOrderDtlEntry.worker,TelenOrderDtlEntry.position,
                case when TelenOrderDtlEntry.ScCount is null then t1.卷数 else TelenOrderDtlEntry.ScCount end 卷数,
                case when TelenOrderDtlEntry.ScCount is null then t1.面积 else 
				(case when  (t1.长度+(t1.边距*2))*(t1.宽度+t1.间距)*t1.张数*TelenOrderDtlEntry.ScCount/1000000 is null then 0 else CAST((t1.长度+(t1.边距*2))*(t1.宽度+t1.间距)*t1.张数*TelenOrderDtlEntry.ScCount/1000000 as decimal(38, 2)) end) end 面积
                from                 
                  (select deliverno 订单号,
                  case when cpwidth is null then 0 else cpwidth end 长度,
                case when cpheight is null then 0 else cpheight end 宽度,
                case when djpages is null then 0 else djpages end 张数,
                case when bianju is null then 0  else  CAST(bianju as decimal(38, 2)) end 边距, 
                case when jianju is null then 0  else jianju end 间距,
				case when unit ='卷' then 
				(case when quantity  is null then 0 else quantity end ) else 
				(case when quantity  is null then 0 else CAST(quantity/ 
				(case when (case when djpages is null then 0 else djpages end)=0 then  1 else djpages end)as decimal(38, 2)) end ) end 卷数,
               case when unit ='卷' then 
                (case when  (cpwidth+(bianju*2))*(cpheight+jianju)*djpages*quantity/1000000 is null then 0 else CAST((cpwidth+(bianju*2))*(cpheight+jianju)*djpages*quantity/1000000 as decimal(38, 2)) end)
                else (case when  (cpwidth+(bianju*2))*(cpheight+jianju)*quantity/1000000 is null then 0 else CAST((cpwidth+(bianju*2))*(cpheight+jianju)*quantity/1000000 as decimal(38, 2)) end) end  面积,
				 prodate 生产日期
                from [telendbs].dbo.TelenOrderDtl  where prodate between '" + dtStart.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dtEnd.ToString("yyyy-MM-dd 23:59:59") + @"'  )t1 left join  TelenOrderDtlEntry  on TelenOrderDtlEntry.deliverno=t1.订单号) t3 
                group by t3.worker";
            DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();
            DataTable dt = DbHelperSQL.ReturnDataTable(sql);



            Decimal price1 = 0;
            Decimal price2 = 0;

            foreach (DataRow item in dt.Rows)
            {
                price1 += Convert.ToDecimal(item["总卷数"]);
                price2 += Convert.ToDecimal(item["总面积"]);
            }

            JObject summary = new JObject();
            summary.Add("worker", "合计");
            summary.Add("总卷数", price1.ToString("F2"));
            summary.Add("总面积", price2.ToString("F2"));
            Grid3.SummaryData = summary;

            Grid3.RecordCount = dt.Rows.Count;
            //q = SortAndPage(q, Grid1);
            dt = GetPagedDataTable( dt, Grid3);
            Grid3.DataSource = dt;
            Grid3.DataBind();


            Grid3.SelectedRowIndex = 0;
        }

        //private void ChangePanel6IFrameUrl()
        //{
        //    int ID = GetSelectedDataKeyID(Grid2);
        //    string DeptName = GetSelectedDataKey(Grid2, 1);
        //    string Date1 = "";
        //    string Date2 = "";
        //    if (dpStart.SelectedDate.HasValue && dpEnd.SelectedDate.HasValue)
        //    {
        //        Date1 = dpStart.SelectedDate.Value.ToString("yyyy-MM-dd");
        //        Date2 = dpEnd.SelectedDate.Value.ToString("yyyy-MM-dd");
        //    }
        //    Panel6.IFrameUrl = "~/Finance/ReimburseChart2.aspx?ID=" + ID + "&&" + "Date1=" + Date1 + "&&Date2=" + Date2 + "&&DeptName=" + HttpUtility.UrlEncode(DeptName, System.Text.Encoding.UTF8);
        //}

        protected void ChangePanel8IFrameUrl()
        {
            string Date1 = "";
            string Date2 = "";
            if (dpStart.SelectedDate.HasValue && dpEnd.SelectedDate.HasValue)
            {
                Date1 = dpStart.SelectedDate.Value.ToString("yyyy-MM-dd");
                Date2 = dpEnd.SelectedDate.Value.ToString("yyyy-MM-dd");
            }
            //Panel8.IFrameUrl= "~/Finance/ReimburseChart3.aspx?Date1=" + Date1 + "&&Date2=" + Date2+"&&class=class1&&class1_param=";

        }

       
    }
}