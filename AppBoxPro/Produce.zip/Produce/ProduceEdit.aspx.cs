﻿using EntityFramework.Extensions;
using FineUIPro;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Entity;
using System.IO;
using SQLHelper;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace AppBoxPro.Produce
{
    public partial class ProduceEdit : PageBase
    {
        #region ViewPower

        /// <summary>
        /// 本页面的浏览权限，空字符串表示本页面不受权限控制
        /// </summary>
        public override string ViewPower
        {
            get
            {
                return "ProduceEdit";
            }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadData();
            }
            else
            {
                string arg = GetRequestEventArgument(); // 此函数所在文件：PageBase.cs
                if (arg == "btnSave")
                {
                    btnSave_Click(sender, e);
                }
            }

        }

        private void LoadData()
        {
            //检测权限
            if (!CheckPower("CoreReimbursePass"))
            {
                //btnChangeEnableUsers.Enabled = false;
            }
            //ResolveEnableStatusButtonForGrid(btnEnableRei, Grid1, true);
            //ResolveEnableStatusButtonForGrid(btnDisableRei, Grid1, false);

            //CheckPowerWithLinkButtonField("CoreReimbursePaid", Grid1, "paid");

            //按钮附加超链接
            //ResolveDeleteButtonForGrid(btnDeleteSelected, Grid1);
            //btnNew.OnClientClick = Window1.GetShowReference("~/Finance/ReimbursesNew.aspx", "新增报销记录");
            // 每页记录数
            Grid1.PageSize = ConfigHelper.PageSize;
            ddlGridPageSize.SelectedValue = ConfigHelper.PageSize.ToString();

            //绑定部门数据
            BindDDLDept();
            //绑定操作人姓名
            BindDDLChineseName();
            BeforeLoad();
            BindGrid();
        }
        private void BeforeLoad()
        {
            //DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["LOCAL_1"].ToString();
            //string sql1 = "select max (salesn) from TelenOrderDtl where prodate is not null";
            //DataTable dataTable = DbHelperSQL.ReturnDataTable(sql1);
            DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["LOCAL_1"].ToString();
            string sql3 = "delete from TelenOrderDtl";
            int result = DbHelperSQL.ExecuteSql(sql3, 40);
            if (result > 0)
            {

                DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["LOCAL_2"].ToString();
                string sql2 = @"SELECT [DeliverNo] ,[client] ,[DeliverDate] ,[NameSpec] ,[Unit] ,[Price] ,[Quantity] ,[SalePrice] ,[Tax] ,[Discount] ,[Fpdanwei] ,[Ysmoney] ,[Maoli] ,[SkDate] ,[Yanshou] ,[Sybumen] ,[Remark] ,[Reserve1] ,[Reserve2] ,[Reserve3] ,[Reserve4] ,[Kpdate] ,[provide] ,[Fukuandate] ,[isFinish] ,[Reserve5] ,[Reserve6] ,[Reserve7] ,[Reserve8] ,[Reserve9] ,[Reserve10] ,[prodate] ,[delivermode] ,[receiver] ,[receiveradd] ,[stockno] ,[Settlement] ,[PSDate] ,[PlanSendDate] ,[bianju] ,[isxudao] ,[jianju] ,[lieshu] ,[fukuan] ,[changdu] ,[juanshu] ,[cpwidth] ,[cpheight] ,[djpages] FROM [telendbs].[dbo].[TelenOrderDtl] ";
                //where salesn>'" + dataTable.Rows[0][0].ToString() + "'";
                DataTable dt = DbHelperSQL.ReturnDataTable(sql2);

                if (dt != null && dt.Rows.Count > 0)
                {
                    SetDataTableToTable(dt, "TelenOrderDtl");

                }
            }


        }
        SqlTransaction tran = null;//声明一个事务对象 

        public bool SetDataTableToTable(DataTable source, string tableName)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["LOCAL_1"].ToString()))
                {
                    conn.Open();//打开链接  
                    using (tran = conn.BeginTransaction())
                    {
                        using (SqlBulkCopy copy = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, tran))
                        {
                            copy.DestinationTableName = tableName;           //指定服务器上目标表的名称

                            #region 进行字段映射

                            foreach (DataColumn temp in source.Columns)
                            {
                                copy.ColumnMappings.Add(temp.ColumnName, temp.ColumnName);
                            }

                            #endregion
                            //Console.WriteLine("194::::"+source.Columns.Count);
                            copy.WriteToServer(source);                      //执行把DataTable中的数据写入DB  
                            tran.Commit();                                      //提交事务  
                            conn.Close();//打开链接  

                            return true;                                        //返回True 执行成功！  
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                if (null != tran)
                    tran.Rollback();
                return false;//返回False 执行失败！ 
            }
        }


        private void BindDDLChineseName()
        {
            //var q = DB.Users.Select(u => u.ChineseName).Distinct();
            //ddlChineseName.DataSource = q;
            //ddlChineseName.DataBind();
            //return;
        }

        private void BindDDLDept()
        {
            //var q = DB.Depts.Where(u => u.Parent == null).Select(u => u.Name).Distinct();
            //ddlDept.DataSource = q;
            //ddlDept.DataBind();

        }




        private void ResolveEnableStatusButtonForGrid(MenuButton btn, Grid grid, bool enabled)
        {
            string enabledStr = "启用";
            if (!enabled)
            {
                enabledStr = "禁用";
            }
            btn.OnClientClick = grid.GetNoSelectionAlertInParentReference("请至少应该选择一项记录！");
            btn.ConfirmText = String.Format("确定要{1}选中的<span class=\"highlight\"><script>{0}</script></span>项记录吗？", grid.GetSelectedCountReference(), enabledStr);
            btn.ConfirmTarget = FineUIPro.Target.Top;
        }


        private void BindGrid()
        {

            DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["LOCAL_1"].ToString();

            string sql = @"select tod.订单号, tod.品名规格, tod.长度, tod.宽度, tod.张数, tod.张数, tod.间距,tod.边距,
                case when todEntry.ScCount is null then tod.数量 else todEntry.ScCount end 数量,tod.生产日期,
                case when todEntry.ScCount is null then tod.面积 else 
                (case when  (tod.长度+(tod.边距*2))*(tod.宽度+tod.间距)*tod.张数*todEntry.ScCount/1000000 is null then 0 else CAST((tod.长度+(tod.边距*2))*(tod.宽度+tod.间距)*tod.张数*todEntry.ScCount/1000000 as decimal(38, 2)) end) end 面积,
                todEntry.worker,todEntry.position,todEntry.productProcess,todEntry.productType ,todEntry.remark,todEntry.packager
                from(
                select deliverno 订单号,nameSpec 品名规格,
                case when cpwidth is null then 0 else cpwidth end 长度,
                case when cpheight is null then 0 else cpheight end 宽度,
                case when djpages is null then 0 else djpages end 张数,
                case when bianju is null then 0  else  CAST(bianju as decimal(38, 2)) end 边距, 
                case when jianju is null then 0  else jianju end 间距,
				case when unit ='卷' then 
				(case when quantity  is null then 0 else quantity end ) else 
				(case when quantity  is null then 0 else CAST(quantity/ 
				(case when (case when djpages is null then 0 else djpages end)=0 then  1 else djpages end)as decimal(38, 2)) end ) end  数量,
				
                case when unit ='卷' then 
                (case when  (cpwidth+(bianju*2))*(cpheight+jianju)*djpages*quantity/1000000 is null then 0 else CAST((cpwidth+(bianju*2))*(cpheight+jianju)*djpages*quantity/1000000 as decimal(38, 2)) end)
                else (case when  (cpwidth+(bianju*2))*(cpheight+jianju)*quantity/1000000 is null then 0 else CAST((cpwidth+(bianju*2))*(cpheight+jianju)*quantity/1000000 as decimal(38, 2)) end) end 面积,
                
				 prodate 生产日期,deliverDate 订单日期,plansenddate 预计交货日期,
				 unit 单位
	  			 from TelenOrderDtl )tod left join [appdb].dbo.TelenOrderDtlEntry todEntry on  tod.订单号=todEntry.deliverno where ";

            if (dpStart.SelectedDate.HasValue && dpEnd.SelectedDate.HasValue)
            {
                DateTime dtStart = dpStart.SelectedDate.Value;
                DateTime dtEnd = dpEnd.SelectedDate.Value;
                sql += "  tod.生产日期 between '" + dtStart.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dtEnd.ToString("yyyy-MM-dd 23:59:59") + "'";
            }
            else
            {
                sql += " DateDiff(dd, tod.生产日期,getdate())=0";
            }

            DataTable dt = DbHelperSQL.ReturnDataTable(sql);


            //DataTable dt2 = null;
            //if (dt != null && dt.Rows.Count > 0)
            //{
            //    string sql2 = "select deliverno,worker,position,productProcess,productType,remark,packager from TelenOrderDtlEntry where deliverno in ('";
            //    foreach (DataRow temp in dt.Rows)
            //    {
            //        sql2 += temp["订单号"].ToString() + "','";
            //    }
            //    sql2 = sql2.Remove(sql2.Trim().Length - 2, 2);
            //    sql2 += ")";

            //    DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();
            //    dt2 = DbHelperSQL.ReturnDataTable(sql2);
            //    dt = GetNewDt(dt, dt2);

            //}

            if (!string.IsNullOrEmpty(tbxProsn.Text))
            {
                string prosn = tbxProsn.Text;
                //1、替换特殊符号 例如 、，；空格
                prosn = ReplaceTeShu(prosn);
                string[] arr = prosn.Split(',');
                StringBuilder sb = new StringBuilder();
                foreach (string temp in arr)
                {
                    if (temp.Trim() != string.Empty)
                    {
                        sb.Append("订单号 like '%" + temp.Trim() + "%' or ");
                    }
                }
                sb=sb.Remove(sb.ToString().Length - 3, 3);
                Debug.WriteLine(sb.ToString());
                DataRow[] drs = dt.Select(sb.ToString());
                dt = SelectDt(dt, drs);
            }

            if (cbxEnd.Checked)
            {
                if (dt.Columns.Contains("worker"))
                {
                    DataRow[] drs = dt.Select(" worker is null or position is null or worker='' or position=''");
                    dt = SelectDt(dt, drs);
                }
            }
            // 1.设置总项数（特别注意：数据库分页一定要设置总记录数RecordCount）
            Grid1.RecordCount = dt.Rows.Count;
            dt = GetPagedDataTable(Grid1.PageIndex, Grid1.PageSize, dt);

            decimal totalPrice = 0;
            foreach (DataRow item in dt.Rows)
            {
                totalPrice += Convert.ToDecimal(item["面积"]);
            }
            JObject jObject = new JObject();
            jObject.Add("journey", "合计");
            jObject.Add("面积", totalPrice);

            //GetPagedDataTable()

            Grid1.DataSource = dt;
            Grid1.DataBind();
            Grid1.SummaryData = jObject;
            //Grid1.SummaryData = summary;
        }
        private string ReplaceTeShu(string str)
        {
            str = str.Replace(" ", ",");
            str = str.Replace("，", ",");
            str = str.Replace("、", ",");
            str = str.Replace("；", ",");
            str = str.Replace(";", ",");
            return str;
        }

        /// <summary>
        /// 返回组合后的页面
        /// </summary>
        /// <param name="deliverDt">订单数据页面</param>
        /// <param name="entryDt">订单附加信息页面</param>
        /// <returns></returns>
        private DataTable GetNewDt(DataTable deliverDt, DataTable entryDt)
        {
            //DataTable dt = deliverDt.Clone();

            if (entryDt != null && entryDt.Rows.Count > 0)
            {
                foreach (DataColumn dc in entryDt.Columns)
                {
                    if (dc.ColumnName != "ScCount")
                        deliverDt.Columns.Add(dc.ColumnName);
                }
                foreach (DataRow dr in entryDt.Rows)
                {
                    DataRow[] deliverDrs = deliverDt.Select("订单号='" + dr["deliverno"].ToString() + "'");
                    foreach (DataColumn dc in entryDt.Columns)
                    {
                        if (dc.ColumnName == "ScCount")
                        {
                            if (dr[dc.ColumnName].ToString().Trim() != string.Empty)
                                deliverDrs[0]["数量"] = dr[dc.ColumnName].ToString();
                        }
                        else
                            deliverDrs[0][dc.ColumnName] = dr[dc.ColumnName].ToString();

                    }

                }
                //return deliverDt;
            }
            return deliverDt;
        }
        /// <summary>
        /// 返回select后的 的数据
        /// </summary>
        /// <param name="dt">原datatable</param>
        /// <param name="drs">datatable select后的行数组</param>
        /// <returns></returns>
        private DataTable SelectDt(DataTable dt, DataRow[] drs)
        {
            DataTable t = dt.Clone();
            t.Clear();
            foreach (DataRow row in drs)
                t.ImportRow(row);
            return t;
        }

        /// <summary>
        /// datatable 分页
        /// </summary>
        /// <param name="pageIndex">页面序号</param>
        /// <param name="pageSize">每页数量</param>
        /// <param name="source">原datatable</param>
        /// <returns>分页后的数据datatable</returns>
        private DataTable GetPagedDataTable(int pageIndex, int pageSize, DataTable source)
        {
            int rowbegin = pageIndex * pageSize;
            int rowend = (pageIndex + 1) * pageSize;

            string sortField = Grid1.SortField;
            string sortDirection = Grid1.SortDirection;
            //Debug.WriteLine(sortField + "." + sortDirection);

            DataView view2 = source.DefaultView;

            view2.Sort = String.Format("{0} {1}", sortField, sortDirection);
            DataTable table = view2.ToTable();

            DataTable paged = table.Clone();

            if (rowend > source.Rows.Count)
            {
                rowend = source.Rows.Count;
            }

            for (int i = rowbegin; i < rowend; i++)
            {
                paged.ImportRow(table.Rows[i]);
            }

            return paged;
        }
        public string Save()
        {
            Dictionary<int, Dictionary<string, object>> modifiedDict = Grid1.GetModifiedDict();
            if (modifiedDict != null && modifiedDict.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                foreach (int rowIndex in modifiedDict.Keys)
                {

                    Dictionary<string, object> modifiedDict2 = modifiedDict[rowIndex];
                    foreach (string rowIndex2 in modifiedDict2.Keys)
                    {
                        //Debug.WriteLine(rowIndex);

                        //Debug.WriteLine(rowIndex2);
                        //Debug.WriteLine(modifiedDict2[rowIndex2]);
                        //Debug.WriteLine(Grid1.DataKeys[rowIndex][0].ToString());
                        //Debug.WriteLine(Grid1.DataKeys[rowIndex][1].ToString());

                        sb.Append(SetSql(rowIndex2, modifiedDict2[rowIndex2].ToString(), Grid1.DataKeys[rowIndex][0].ToString(), Grid1.DataKeys[rowIndex][1].ToString()));

                    }
                    //int rowID = Convert.ToInt32(Grid1.DataKeys[rowIndex][0]);



                }
                if (sb.ToString().Trim() != string.Empty)
                {
                    DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();
                    DbHelperSQL.ExecuteSql(sb.ToString().Trim(), 300);
                }
                BindGrid();
                return "true";

            }
            return "false";

        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("376");

            Dictionary<int, Dictionary<string, object>> modifiedDict = Grid1.GetModifiedDict();
            if (modifiedDict != null && modifiedDict.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                foreach (int rowIndex in modifiedDict.Keys)
                {

                    Dictionary<string, object> modifiedDict2 = modifiedDict[rowIndex];
                    foreach (string rowIndex2 in modifiedDict2.Keys)
                    {
                        if (HasChinese(rowIndex2))
                        {
                            //检测权限
                            if (CheckPower("ProduceDataChange"))
                            {
                                if (rowIndex2 == "数量")
                                {
                                    sb.Append(SetSql("ScCount", modifiedDict2[rowIndex2].ToString(), Grid1.DataKeys[rowIndex][0].ToString(), Grid1.DataKeys[rowIndex][1].ToString()));
                                }
                            }

                        }
                        else
                            sb.Append(SetSql(rowIndex2, modifiedDict2[rowIndex2].ToString(), Grid1.DataKeys[rowIndex][0].ToString(), Grid1.DataKeys[rowIndex][1].ToString()));

                    }
                    //int rowID = Convert.ToInt32(Grid1.DataKeys[rowIndex][0]);
                }
                if (sb.ToString().Trim() != string.Empty)
                {
                    DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["Default"].ToString();
                    Debug.WriteLine("执行sql:\r\n" + sb.ToString());
                    DbHelperSQL.ExecuteSql(sb.ToString().Trim(), 300);
                }
                BindGrid();
            }


            //Grid1.DataBind();
        }
        /// <summary>
        /// 判断字符串中是否包含中文
        /// </summary>
        /// <param name="str">需要判断的字符串</param>
        /// <returns>判断结果</returns>
        public bool HasChinese(string str)
        {
            return Regex.IsMatch(str, @"[\u4e00-\u9fa5]");
        }

        /// <summary>
        /// 得到修改信息的sql语句
        /// </summary>
        /// <param name="columnName">列名</param>
        /// <param name="value">数值</param>
        /// <param name="deliverno">工单号</param>
        /// <param name="prodate">生产日期</param>
        /// <returns>sql语句</returns>
        private string SetSql(string columnName, string value, string deliverno, string prodate)
        {
            if (value.Trim() != string.Empty)
            {
                string sql = string.Format(@"
                         update [TelenOrderDtlEntry] set {0}='{1}' where [deliverno]='{2}'
                         if (select @@ROWCOUNT)=0 begin 
                         insert [TelenOrderDtlEntry]([deliverno],{0},prodate)
                         VALUES('{2}','{1}','{3}') end;", columnName, value, deliverno, prodate);
                return sql;
            }
            
            return string.Empty;
        }
        private void TT()
        {
            //bool cbx = cbxEnd.Checked;


            //通过 和 未通过的总数
            var qq1 = from a in DB.reimbursements
                      group a by new
                      {
                          a.ReimburseSummary.ID
                      } into g
                      select new
                      {
                          g.Key.ID,
                          TotalPrice = g.Sum(p => p.price),
                          s1 = g.Sum(p => p.passed == true ? 1 : 0),
                          s2 = g.Sum(p => p.passed == false ? 1 : 0),
                          s3 = g.Sum(p => p.paid == true ? 1 : 0),
                          s4 = g.Sum(p => p.paid == false ? 1 : 0),
                      };

            //只显示未完结：未通过为0，未支付为0
            //if (cbx)
            //{
            //    qq1 = qq1.Where(u => u.s2 != 0 || u.s4 != 0);
            //}


            var qq2 = from a in DB.reimburseSummaries select a;

            string name = GetIdentityName();
            var q = from a in qq2
                    join m in qq1 on a.ID equals m.ID into m_join
                    from m in m_join
                    select new
                    {
                        a.prosn,
                        a.ID,
                        a.InputDate,

                        a.journey,
                        a.hasPay,
                        a.isPassed,
                        a.remark,
                        chinesename = a.user.ChineseName,
                        a.user,
                        m.s1,
                        m.s2,
                        m.s3,
                        m.s4,
                        s5 = m.s1 + "/" + (m.s1 + m.s2),
                        s6 = m.s3 + "/" + (m.s3 + m.s4),

                        price = m.TotalPrice
                    };

            //查看权限，如果不是管理员，过滤掉不是自己的记录
            if (!CheckPower("CoreReimburseAll"))
            {
                q = q.Where(u => u.user.Name == name);
            }

            if (!string.IsNullOrEmpty(tbxProsn.Text))
            {
                string prosn = tbxProsn.Text;
                q = q.Where(u => u.prosn.Contains(prosn));
            }

            //if (ddlDept.SelectedIndex != -1)
            //{
            //    string dept = ddlDept.SelectedText;
            //    q = q.Where(u => u.user.Dept.Name == dept);
            //}


            //if (ddlChineseName.SelectedIndex != -1)
            //{
            //    string chineseName = ddlChineseName.SelectedText;
            //    //中文名搜索
            //    q = q.Where(u => u.user.ChineseName == chineseName);
            //}



            if (dpStart.SelectedDate.HasValue && dpEnd.SelectedDate.HasValue)
            {
                DateTime dtStart = dpStart.SelectedDate.Value;
                DateTime dtEnd = dpEnd.SelectedDate.Value.AddDays(1);
                q = q.Where(u => u.InputDate >= dtStart && u.InputDate <= dtEnd);
            }
            Decimal price = 0;
            Decimal? journey = 0;


            foreach (var item in q)
            {
                price += item.price;
            }

            JObject summary = new JObject();
            summary.Add("chinesename", "合计");
            summary.Add("price", price.ToString("F2"));
            //summary.Add("journey", journey);

            Grid1.RecordCount = q.Count();
            q = SortAndPage(q, Grid1);

        }

        protected void Grid1_Sort(object sender, FineUIPro.GridSortEventArgs e)
        {
            //    Grid1.SortDirection = e.SortDirection;
            //    Grid1.SortField = e.SortField;
            BindGrid();
        }

        protected void Grid1_PreDataBound(object sender, EventArgs e)
        {

        }

        protected void Grid1_RowCommand(object sender, FineUIPro.GridCommandEventArgs e)
        {
            int id = GetSelectedDataKeyID(Grid1);
            //string userName = GetSelectedDataKey(Grid1, 1);

            if (e.CommandName == "Paid")
            {
                Prompt prompt = new Prompt();


                var q = DB.reimbursements.Where(u => u.ReimburseSummary.ID == id);
                foreach (var item in q)
                {
                    item.paid = true;
                }
                DB.SaveChanges();
                BindGrid();
            }

            if (e.CommandName == "Print")
            {
                PageContext.RegisterStartupScript(Window1.GetShowReference("~/Finance/ReimbursesPrint.aspx?ID=" + id, "打印", 1300, 700));
            }
        }

        protected void Grid1_PageIndexChange(object sender, FineUIPro.GridPageEventArgs e)
        {
            Grid1.PageIndex = e.NewPageIndex;
            BindGrid();
        }

        protected void Window1_Close(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void btnDeleteSelected_Click(object sender, EventArgs e)
        {
            List<int> ids = GetSelectedDataKeyIDs(Grid1);

            if (ids.Count <= 0)
            {
                Alert.Show("请选择要删除的记录");
                return;
            }

            //DB.images.Where(u => ids.Contains(u.reimbursement.ID)).Delete();

            //先删除总工单的明细
            DB.reimbursements.Where(u => ids.Contains(u.ReimburseSummary.ID)).Delete();

            //再删除总工单
            DB.reimburseSummaries.Where(u => ids.Contains(u.ID)).Delete();

            // 重新绑定表格
            BindGrid();

            //WriteLog(GetIdentityName());
        }

        private void WriteLog(string username)
        {
            //string strFilePath = Server.MapPath("~/Finance/Logs/logs.txt");
            //System.IO.FileStream fs = new System.IO.FileStream(strFilePath, System.IO.FileMode.Append);
            //System.IO.StreamWriter sw = new System.IO.StreamWriter(fs, System.Text.Encoding.Default);
            //sw.WriteLine(username+"删除操作" + DateTime.Now.ToString());
            //sw.Close();
            //fs.Close();
        }


        protected void ddlGridPageSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            Grid1.PageSize = Convert.ToInt32(ddlGridPageSize.SelectedValue);

            BindGrid();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Dictionary<int, Dictionary<string, object>> modifiedDict = Grid1.GetModifiedDict();
            if (modifiedDict != null && modifiedDict.Count > 0)
            {
                Alert.ShowInTop("表单数据未保存，请先保存后再继续搜索", String.Empty, MessageBoxIcon.Question, "");
            }
            else
            {
                BindGrid();
            }
        }

        protected void btnEnableRei_Click(object sender, EventArgs e)
        {
            SetSelectedUsersEnableStatus(true);
        }

        protected void btnDisableRei_Click(object sender, EventArgs e)
        {
            SetSelectedUsersEnableStatus(false);
        }

        private void SetSelectedUsersEnableStatus(bool enabled)
        {
            List<int> ids = GetSelectedDataKeyIDs(Grid1);

            DB.reimbursements.Where(u => ids.Contains(u.ID)).Update(u => new Reimbursement { passed = enabled });

            BindGrid();
        }

        protected void Grid1_RowDoubleClick(object sender, GridRowClickEventArgs e)
        {
            //int ID = GetSelectedDataKeyID(Grid1);
            int ID = Convert.ToInt32(Grid1.DataKeys[e.RowIndex][0]);
            PageContext.RegisterStartupScript(Window1.GetShowReference("~/Finance/ReimbursesEdit.aspx?ID=" + ID, "编辑"));
        }

        protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDDLChineseName();
        }
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void cbxEnd_CheckedChanged(object sender, CheckedEventArgs e)
        {
            Dictionary<int, Dictionary<string, object>> modifiedDict = Grid1.GetModifiedDict();
            if (modifiedDict != null && modifiedDict.Count > 0)
            {
                Alert.ShowInTop("表单数据未保存，请先保存后再继续操作", String.Empty, MessageBoxIcon.Question, "");
                cbxEnd.Checked = false;
            }
            else
                BindGrid();
        }

        protected void DropDownList2_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }
    }
}