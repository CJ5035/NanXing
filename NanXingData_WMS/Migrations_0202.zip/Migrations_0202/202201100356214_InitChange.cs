namespace NanXingData_WMS.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitChange : DbMigration
    {
        public override void Up()
        {
           
        }
        
        public override void Down()
        {
            
        }
    }
}
